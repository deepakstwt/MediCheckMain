import SwiftUI
import UserNotifications

@main
struct MediCheckApp: App {
   

    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
